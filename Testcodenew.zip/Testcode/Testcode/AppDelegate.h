//
//  AppDelegate.h
//  Testcode
//
//  Created by Thabu on 12/02/18.
//  Copyright © 2018 gopinath. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

