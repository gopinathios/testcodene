//
//  detailTableViewCell.h
//  Testcode
//
//  Created by Thabu on 12/02/18.
//  Copyright © 2018 gopinath. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface detailTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *descriptionlable;
@property (weak, nonatomic) IBOutlet UILabel *titlelable;
@property (weak, nonatomic) IBOutlet UIImageView *imagecell;

@end
